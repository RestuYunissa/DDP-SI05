from animals import *

class Burung(animals):
    def __init__(self, nama, makanan, hidup, berkembang_biak, jenis_bulu, bunyi):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.jenis_bulu = jenis_bulu
        self.bunyi = bunyi

    def cetak_burung(self):
        super().cetak()
        print(f'Hewan ini berbulu {self.jenis_bulu} dan hewan ini berbunyi {self.bunyi}')

print('\n----- Objek Pertama -----')
Beo = Burung('Burung Beo', 'Biji-bijian', 'Udara', 'Bertelur', 'Blue and Orange', 'Kamu jelek')
Beo.cetak_burung()

print('\n----- Objek Kedua -----')
Merpati = Burung('Burung Merpati', 'Biji-bijian', 'Udara', 'Bertelur', 'Putih', 'kugeru kugeru')
Merpati.cetak_burung()
