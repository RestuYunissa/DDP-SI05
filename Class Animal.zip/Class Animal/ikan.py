from animals import *
class ikan(animals):
    def __init__(self, nama, makanan, hidup, berkembang_biak, warna_ikan, jenis_ikan):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.warna_ikan = warna_ikan
        self.jenis = jenis_ikan

    def cetak_ikan(self):
        super().cetak()
        print(f'warna ikan ini adalah {self.warna_ikan} dan hewan ini jenisnya ikan {self.jenis}')

Nemo = ikan('Ikan Nemo', 'plankton', 'air', 'bertelur', 'orange', 'air laut')
Nemo.cetak_ikan()
