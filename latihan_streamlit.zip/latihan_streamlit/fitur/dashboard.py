import streamlit as st

st.title('Halaman Dashboard')
st.image('rumah.jpg', caption='gambar rumah')

# Fungsi menghitung dan menyimpan total
def total():
    total_nabung = sum(s['Jumlah']
                       for s in st.session_state
                       ['total_semua']
                       if s ['Tipe'] == 'Menabung')
    
    return total_nabung

total_semua = st.session_state['']
total_nabung = total()

st.metric('Total menabung', f'Rp {total_nabung}')