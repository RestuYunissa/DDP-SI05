class Gempa:
    # Konstruktor Inisialisasi atribut
    def __init__(self, lokasi, skala) :
        self.lokasi = lokasi
        self.skala = skala

    # Method penentu skala gempa
    def dampak(self):
        # Logika/statement
        if self.skala < 2:
            print('gempa tidak berasa')
        elif 2 <= self.skala <= 4:
            print('Gempa berdampak bangunan retak-retak')
        elif 4 <= self.skala <= 6:
            print('Gempa berdampak bangunan roboh')
        elif self.skala > 6:
            print('Gempa berdampak bangunan roboh dan berpotensi tsunami')
      
        # Menampilkan lokasi dan skala gempa
        print(f'Lokasi Gempa: {self.lokasi}')
        print(f'Skala Gempa: {self.skala}')